@extends('errors::minimal')

@section('title', __('419 Page Expired'))
@section('code', '419')
@section('message', __('Page Expired'))
