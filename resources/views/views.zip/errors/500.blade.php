@extends('errors::minimal')

@section('title', __('500 Server Error'))
@section('code', '500')
@section('message', __('Server Error'))
