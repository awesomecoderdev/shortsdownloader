@extends('errors::minimal')

@section('title', __('503 Service Unavailable'))
@section('code', '503')
@section('message', __('Service Unavailable'))
