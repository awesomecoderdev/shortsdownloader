@extends('errors::minimal')

@section('title', __('404 Not Found'))
@section('code', '404')
@section('message', __('Not Found'))
