@extends('errors::minimal')

@section('title', __('401 Unauthorized'))
@section('code', '401')
@section('message', __('Unauthorized'))
